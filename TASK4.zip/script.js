const products = [
    { name: "Personal Portfolio Website", category: "Web Development", price: "Free", rating: 4.8 },
    { name: "Task Manager App", category: "Productivity", price: "Free", rating: 4.5 },
    { name: "E-commerce Store", category: "Web Development", price: "$20", rating: 4.7 },
];
const productList = document.getElementById('product-list');

function displayProducts(products) {
    productList.innerHTML = '';
    products.forEach(p => {
        const li = document.createElement('li');
        li.textContent = `${p.name} - Category: ${p.category}, Rating: ${p.rating}`;
        productList.appendChild(li);
    });
}

displayProducts(products);

const tasksUl = document.getElementById('tasks');
const taskInput = document.getElementById('todo-input');
const addTaskBtn = document.getElementById('add-task');

function loadTasks() {
    const tasks = JSON.parse(localStorage.getItem('tasks')) || [];
    tasksUl.innerHTML = '';
    tasks.forEach((task, index) => {
        addTaskToDOM(task, index);
    });
}

function addTaskToDOM(task, index) {
    const li = document.createElement('li');
    li.textContent = task;

    const delBtn = document.createElement('button');
    delBtn.textContent = 'Delete';
    delBtn.className = 'delete-btn';
    delBtn.addEventListener('click', () => {
        deleteTask(index);
    });

    li.appendChild(delBtn);
    tasksUl.appendChild(li);
}

function saveTasks(tasks) {
    localStorage.setItem('tasks', JSON.stringify(tasks));
}

function deleteTask(index) {
    let tasks = JSON.parse(localStorage.getItem('tasks')) || [];
    tasks.splice(index, 1);
    saveTasks(tasks);
    loadTasks();
}

addTaskBtn.addEventListener('click', () => {
    if(taskInput.value.trim() !== '') {
        let tasks = JSON.parse(localStorage.getItem('tasks')) || [];
        tasks.push(taskInput.value.trim());
        saveTasks(tasks);
        loadTasks();
        taskInput.value = '';
    }
});

loadTasks();

const contactForm = document.getElementById('contact-form');
contactForm.addEventListener('submit', (e) => {
    e.preventDefault();
    alert('Thank you for contacting us!');
    contactForm.reset();
});
